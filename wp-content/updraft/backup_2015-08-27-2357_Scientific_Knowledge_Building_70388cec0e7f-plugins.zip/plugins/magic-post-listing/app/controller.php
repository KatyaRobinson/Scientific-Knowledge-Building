<?php
/** no direct access **/
defined('_WBMPLEXEC_') or die();

class WBMPL_controller extends WBMPL_base
{
    public function __construct()
    {
    }
}