jQuery( document ).ready(function( $ ) {

    $('.flashcard-container li div.back').hide().css('left', 0);
    
    function mySideChange(front) {
        if (front) {
            $(this).parent().find('div.front').show();
            $(this).parent().find('div.back').hide();
            
        } else {
            $(this).parent().find('div.front').hide();
            $(this).parent().find('div.back').show();
        }
    }
    
    /* Replaced hover action with click action as Daniel Clarke suggested */ 
    $('.flashcard-container li').click(
        function () {
            $(this).find('div').stop().rotate3Di('toggle', 150, {direction: 'clockwise', sideChange: mySideChange});
        }
    );
});