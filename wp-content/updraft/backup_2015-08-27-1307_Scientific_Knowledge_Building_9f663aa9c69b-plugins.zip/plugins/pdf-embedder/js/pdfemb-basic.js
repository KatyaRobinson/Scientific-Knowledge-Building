
function pdfembGetPDF(url, callback) {
	    	
	callback(url, false);

};

function pdfembWantMobile($, divContainer, wantWidth, wantHeight) {
	return false;
}

function pdfembMakeMobile($, wantMobile, innerdiv) {
}

function pdfembAddMoreToolbar($, toolbar, divContainer) {
}
