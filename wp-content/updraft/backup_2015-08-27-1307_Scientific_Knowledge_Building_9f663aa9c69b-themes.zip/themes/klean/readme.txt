Thankyou for using Klean WordPress theme.
Klean WordPress theme is based on Underscores Framework http://underscore.me/, (C) 2012-2013 Automattic Inc.
The theme comes under GNU General Public license. For more details about the license, you can always refer to the license.txt file present in the theme.

INSTRUCTIONS FOR USE


	Well, there is not much to it. It’s a very easy theme to setup. But for the sake of clarity, here are some of the points you should keep in mind applying this theme to your project-

	1. The  minimum size of the header image should be at least 1440*900. Otherwise, the image may look stretched or blurred.

	2. The recommended size for the featured images in posts is 400*400. 

	3. The posts do not currently have a full width feature. It will be added in future updates to the theme.


	
For any assistance, you can contact me at the WordPress support forums.