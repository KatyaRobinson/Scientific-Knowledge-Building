/**
 * Admin Metabox 
 * Metabox custom jquery functions
 */
 
jQuery(document).ready(function() {
	jQuery('#catchbase-ui-tabs').tabs();
});