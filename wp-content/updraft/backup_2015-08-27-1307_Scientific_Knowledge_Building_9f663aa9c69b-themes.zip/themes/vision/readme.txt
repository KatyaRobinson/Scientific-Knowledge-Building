This is blog wordpress theme. 

For your any question or request please feel free to contact me. I will be happy to help => mail@burak-aydin.com


PSD by -> https://www.behance.net/gallery/Vision-Theme-PortfolioBlog/7864889



== How to use slider ==

- Ideal slider image size -> 1920px x 400px


== Copyright ==
Vision, Burak Aydin Copyright 2014
Vision is distributed under the terms of the GNU GPL
 
Vision is built with the following resources:

Slider image in screenshot.png - http://pixabay.com/en/washington-dc-memorial-bridge-142169/
Licensed under CC0

Icon Fonts: Font Awesome - http://fontawesome.io/
License: Font: SIL OFL 1.1, CSS: MIT License

Bootstrap - Copyright 2011-2014 Twitter, Inc.
Licensed under MIT

HTML5 Shiv - https://github.com/aFarkas/html5shiv
Licensed under MIT

TGM Plugin - https://github.com/thomasgriffin/TGM-Plugin-Activation
Licensed under GPL v2 or later

Modernizr - http://modernizr.com/
Licensed under MIT

Advanced Custom Fields - http://www.advancedcustomfields.com/
Licensed under GPL

SmoothScroll - https://github.com/galambalazs/smoothscroll
Licensed under MIT

jQuery FlexSlider - https://github.com/woothemes/flexslider
Licensed under GPL v2 or later