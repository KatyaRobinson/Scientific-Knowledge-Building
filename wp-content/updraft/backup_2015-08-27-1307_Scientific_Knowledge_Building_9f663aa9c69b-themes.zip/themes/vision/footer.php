<footer class="bottom-footer">
		
		<div class="container">
			
			<div class="row">
				
				<div class="copyright">
					
					<p>&copy; <?php echo date('Y'); ?> <span class="footer-desc">| <?php _e('All Rights Reserved','vision'); ?> | <?php bloginfo('description' ); ?></span></p>

				</div> <!-- end copyright -->

				<div class="bookmark">
					
					<p><?php _e('Theme by','vision'); ?> <a href="http://burak-aydin.com">Burak Aydin</a> | <span><?php _e('Powered by','vision'); ?></span> <a href="http://wordpress.org">WordPress</a></p>

				</div> <!-- end bookmark -->

			</div> <!-- end row -->

		</div> <!-- end container -->

</footer> <!-- end bottom-footer -->

<?php wp_footer(); ?>

</body>
</html>