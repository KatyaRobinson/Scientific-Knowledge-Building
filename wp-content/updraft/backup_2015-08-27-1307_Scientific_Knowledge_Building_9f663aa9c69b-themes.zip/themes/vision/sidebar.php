<?php if(!dynamic_sidebar('sidebar')): ?>

			<div class="default-sidebar">
				<h3><?php bloginfo('name' ); ?></h2>
				<p><?php bloginfo('description' ); ?></p>
			</div>

<?php endif; ?>