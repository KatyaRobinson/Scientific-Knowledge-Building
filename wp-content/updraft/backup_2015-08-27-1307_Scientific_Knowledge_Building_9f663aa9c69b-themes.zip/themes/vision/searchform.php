<form role="search" method="get" id="searchform" action="<?php echo esc_url(home_url( '/' )); ?>" class="form-inline">
  
        <input type="text" value="" name="s" id="s" class="form-control" placeholder="<?php _e('Search...','vision'); ?>"/>
        <a><i class="fa fa-search"></i></a>
  
</form>