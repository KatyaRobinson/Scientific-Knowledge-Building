<div class="no-post">

	<p><?php echo _e('No posts found. You can search the below.','vision'); ?></p>

	<?php get_search_form(); ?>
	
</div> <!-- no-post -->